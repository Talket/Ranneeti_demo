let globalCases = [];
let allNodesMap = new Map();
let allEdgesList = [];
let adjacency = new Map();

// Style Maps
const TYPE_COLOR = {
  'PERSON': '#ece5d3',
  'ORGANIZATION': '#9a86b3',
  'LOCATION': '#7897b3',
  'EVENT': '#c1443c',
  'DEFAULT': '#6fa8a0'
};
const TYPE_LABEL = {
  'PERSON': 'Person',
  'ORGANIZATION': 'Organisation',
  'LOCATION': 'Location',
  'EVENT': 'Event',
  'DEFAULT': 'Entity'
};

// State
let simulation, svg, nodeSel, linkSel, labelSel, zoomGroup;
let currentNodes = [];
let currentLinks = [];
let caseFilter = document.getElementById('case-filter');
let searchInput = document.getElementById('search-input');
let fileUpload = document.getElementById('file-upload');
let selectedNodeId = null;

function initData(json) {
  globalCases = json.cases || (Array.isArray(json) ? json : [json]);

  // Build Filter
  caseFilter.innerHTML = '<option value="ALL">All Connected Cases</option>';
  globalCases.forEach(c => {
    if (c.case_id) {
      const opt = document.createElement('option');
      opt.value = c.case_id;
      opt.textContent = c.case_id;
      caseFilter.appendChild(opt);
    }
  });

  const stamp = document.getElementById('status-stamp');
  stamp.textContent = 'DATA LOADED';
  stamp.classList.add('ready');

  renderOverview();
  renderGraphLegend();
  updateGraphView('ALL');
}

function processGraphData(mode, payload) {
  let tempNodesMap = new Map();
  let tempEdgesList = [];

  const addNode = (n, isEvent = false, caseObj) => {
    const id = n.entity_id || n.event_id;
    if (!tempNodesMap.has(id)) {
      tempNodesMap.set(id, { 
        ...n, 
        id: id, 
        name: n.text_or_value || n.event_type || id,
        type: isEvent ? 'EVENT' : (n.entity_type || 'DEFAULT'),
        _caseContexts: [caseObj]
      });
    } else {
      tempNodesMap.get(id)._caseContexts.push(caseObj);
    }
  };

  const addEdge = (r) => {
    tempEdgesList.push({
      source: r.source, 
      target: r.target, 
      label: r.relationship_type,
      ...r
    });
  };

  globalCases.forEach(c => {
    if (mode === 'CASE' && c.case_id !== payload) return;
    if (c.task_targets) {
      if (c.task_targets.entities) c.task_targets.entities.forEach(n => addNode(n, false, c));
      if (c.task_targets.events) c.task_targets.events.forEach(n => addNode(n, true, c));
      if (c.task_targets.relationships) c.task_targets.relationships.forEach(addEdge);
    }
  });

  // Build Adjacency
  adjacency.clear();
  tempNodesMap.forEach((_, id) => adjacency.set(id, new Set()));
  tempEdgesList.forEach(e => {
    if(!tempNodesMap.has(e.source)) { tempNodesMap.set(e.source, {id:e.source, name:e.source, type:'DEFAULT'}); adjacency.set(e.source, new Set()); }
    if(!tempNodesMap.has(e.target)) { tempNodesMap.set(e.target, {id:e.target, name:e.target, type:'DEFAULT'}); adjacency.set(e.target, new Set()); }
    adjacency.get(e.source).add(e.target);
    adjacency.get(e.target).add(e.source);
  });

  currentNodes = Array.from(tempNodesMap.values());
  currentLinks = tempEdgesList;
}

function updateGraphView(mode, payload) {
  processGraphData(mode, payload);
  drawD3Graph();
}

function drawD3Graph() {
  const holder = document.getElementById('graph-holder');
  holder.innerHTML = '';
  const width = holder.clientWidth || 800;
  const height = holder.clientHeight || 600;
  
  selectedNodeId = null; // Reset selection on redraw

  svg = d3.select('#graph-holder').append('svg')
    .attr('viewBox', [0,0,width,height])
    .attr('width','100%').attr('height','100%');

  zoomGroup = svg.append('g');
  svg.call(d3.zoom().scaleExtent([0.1, 4]).on('zoom', (ev) => zoomGroup.attr('transform', ev.transform)))
     .on('click', (ev) => {
       // Clear selection if clicking on empty background
       if(ev.target.tagName === 'svg') {
         selectedNodeId = null;
         updateHighlighting();
       }
     });

  const nodes = currentNodes.map(d => Object.create(d));
  const links = currentLinks.map(d => Object.create(d));

  // Anti-scatter physics: weak x/y forces keep disconnected nodes in view
  simulation = d3.forceSimulation(nodes)
    .force('link', d3.forceLink(links).id(d => d.id).distance(60).strength(0.4))
    .force('charge', d3.forceManyBody().strength(-200))
    .force('center', d3.forceCenter(width/2, height/2))
    .force('x', d3.forceX(width/2).strength(0.04))
    .force('y', d3.forceY(height/2).strength(0.04))
    .force('collision', d3.forceCollide().radius(18));

  linkSel = zoomGroup.append('g')
    .attr('stroke', 'var(--thread)')
    .selectAll('line').data(links).join('line')
    .attr('stroke-width', 1.5)
    .attr('opacity', 0.4);

  const nodeG = zoomGroup.append('g').selectAll('g').data(nodes).join('g')
    .attr('cursor','pointer')
    .call(d3.drag()
      .on('start', (ev,d) => { if(!ev.active) simulation.alphaTarget(0.3).restart(); d.fx=d.x; d.fy=d.y; })
      .on('drag', (ev,d) => { d.fx=ev.x; d.fy=ev.y; })
      .on('end', (ev,d) => { if(!ev.active) simulation.alphaTarget(0); d.fx=null; d.fy=null; }))
    .on('click',(ev,d) => {
      ev.stopPropagation();
      selectedNodeId = d.id;
      showDetail(d);
      updateHighlighting();
    });

  nodeSel = nodeG.append('circle')
    .attr('r', 8)
    .attr('fill', d => TYPE_COLOR[d.type] || TYPE_COLOR['DEFAULT'])
    .attr('stroke', 'var(--ink-navy)')
    .attr('stroke-width', 1.5);

  labelSel = nodeG.append('text')
    .attr('class','node-label')
    .attr('x', 12)
    .attr('y', 3)
    .text(d => d.name);

  simulation.on('tick', () => {
    linkSel
      .attr('x1', d => d.source.x)
      .attr('y1', d => d.source.y)
      .attr('x2', d => d.target.x)
      .attr('y2', d => d.target.y);
    nodeG.attr('transform', d => `translate(${d.x},${d.y})`);
  });
}

function getConnectedComponent(startIds) {
  const visited = new Set();
  const queue = [...startIds];
  queue.forEach(id => visited.add(id));
  
  while(queue.length > 0) {
    const curr = queue.shift();
    const neighbors = adjacency.get(curr);
    if(neighbors) {
      neighbors.forEach(n => {
        if(!visited.has(n)) {
          visited.add(n);
          queue.push(n);
        }
      });
    }
  }
  return visited;
}

function updateHighlighting(searchMatches = null) {
  let activeNodes = new Set();
  let explicitHighlights = new Set();

  if (selectedNodeId) {
    // If a node is clicked, highlight its entire connected component
    activeNodes = getConnectedComponent([selectedNodeId]);
    explicitHighlights.add(selectedNodeId);
  } else if (searchMatches && searchMatches.size > 0) {
    // If searching, highlight components of all matched nodes
    activeNodes = getConnectedComponent(Array.from(searchMatches));
    explicitHighlights = searchMatches;
  }

  const isFilterActive = activeNodes.size > 0;

  // Update Opacities and Styles
  nodeSel
    .attr('opacity', d => (!isFilterActive || activeNodes.has(d.id)) ? 1 : 0.1)
    .attr('stroke', d => explicitHighlights.has(d.id) ? '#ffffff' : 'var(--ink-navy)')
    .attr('stroke-width', d => explicitHighlights.has(d.id) ? 3 : 1.5)
    .attr('r', d => explicitHighlights.has(d.id) ? 11 : 8);

  labelSel
    .attr('opacity', d => (!isFilterActive || activeNodes.has(d.id)) ? 1 : 0.1)
    .attr('font-weight', d => explicitHighlights.has(d.id) ? 'bold' : 'normal')
    .attr('fill', d => explicitHighlights.has(d.id) ? '#ffffff' : 'var(--text-dim)');

  linkSel
    .attr('opacity', d => {
      if (!isFilterActive) return 0.4;
      return (activeNodes.has(d.source.id) && activeNodes.has(d.target.id)) ? 0.8 : 0.04;
    })
    .attr('stroke-width', d => {
      if (!isFilterActive) return 1.5;
      return (explicitHighlights.has(d.source.id) || explicitHighlights.has(d.target.id)) ? 2.5 : 1.5;
    })
    .attr('stroke', d => {
      if (!isFilterActive) return 'var(--thread)';
      return (explicitHighlights.has(d.source.id) || explicitHighlights.has(d.target.id)) ? 'var(--brass-bright)' : 'var(--thread)';
    });
}

function showDetail(d) {
  const panel = document.getElementById('detail-panel');
  const neighbors = Array.from(adjacency.get(d.id) || []).map(nId => {
    let n = currentNodes.find(cn => cn.id === nId);
    return n ? n.name : nId;
  });

  const attrs = d.attributes || {};
  let attrHtml = '';
  for(const [k,v] of Object.entries(attrs)) {
    attrHtml += `<div class="row"><span>${k}</span><span style="text-align:right;max-width:180px;">${Array.isArray(v)?v.join(', '):v}</span></div>`;
  }

  const prov = d.provenance || [];
  let provHtml = '';
  
  if (prov.length > 0) {
    provHtml = prov.map(p => `
      <div class="evidence-item">
        <span class="src" style="color:var(--steel)">PROVENANCE (SOURCE LINE)</span>
        <div style="margin-top:3px;font-family:'IBM Plex Mono';font-size:11px;">${p}</div>
      </div>
    `).join('');
  } else if (d._caseContexts && d._caseContexts.length > 0) {
    const caseInfos = d._caseContexts.map(c => {
      let info = c.case_id;
      if (c.document_context) {
        if (c.document_context.nia_fir_no) info += ` (FIR: ${c.document_context.nia_fir_no})`;
        else if (c.document_context.state_fir_no) info += ` (FIR: ${c.document_context.state_fir_no})`;
      }
      return info;
    });
    
    provHtml = `
      <div class="evidence-item">
        <span class="src" style="color:var(--olive)">CONTEXTUAL INFERENCE</span>
        <div style="margin-top:3px;font-family:'IBM Plex Mono';font-size:11px;">
          Extracted from the structural context of:<br>
          <strong style="color:var(--paper)">${caseInfos.join('<br>')}</strong><br><br>
          <em>(No explicit text-span provenance was provided in the JSON, but this entity was explicitly listed as part of the case file's targets.)</em>
        </div>
      </div>
    `;
  }

  panel.innerHTML = `
    <h3>${d.name}</h3>
    <span class="type-badge" style="background:${(TYPE_COLOR[d.type]||TYPE_COLOR['DEFAULT'])}22;color:${TYPE_COLOR[d.type]||TYPE_COLOR['DEFAULT']};border:1px solid ${TYPE_COLOR[d.type]||TYPE_COLOR['DEFAULT']}">${TYPE_LABEL[d.type]||d.type}</span>
    ${d.epistemic_state ? `<span class="flag">⚠ ${d.epistemic_state}</span>` : ''}
    
    <h4 style="margin:16px 0 6px;color:var(--paper);font-size:12px;font-family:'IBM Plex Mono',monospace;letter-spacing:.5px;">ATTRIBUTES</h4>
    ${attrHtml || '<div class="row"><span>None listed</span></div>'}
    
    <h4 style="margin:16px 0 6px;color:var(--paper);font-size:12px;font-family:'IBM Plex Mono',monospace;letter-spacing:.5px;">CONNECTED TO</h4>
    <div style="font-size:12px;line-height:1.9;color:var(--brass-bright)">${neighbors.join(', ') || '&mdash; (No relationships explicitly defined)'}</div>
    
    <h4 style="margin:16px 0 6px;color:var(--paper);font-size:12px;font-family:'IBM Plex Mono',monospace;letter-spacing:.5px;">EVIDENCE / SOURCE</h4>
    ${provHtml || '<div class="empty-hint">No source or context found (orphaned node).</div>'}
  `;
}

function renderOverview() {
  const kpiRow = document.getElementById('kpi-row');
  let tCases = globalCases.length;
  let tNodes = 0; let tEdges = 0;
  globalCases.forEach(c => {
    if(c.task_targets) {
      if(c.task_targets.entities) tNodes += c.task_targets.entities.length;
      if(c.task_targets.events) tNodes += c.task_targets.events.length;
      if(c.task_targets.relationships) tEdges += c.task_targets.relationships.length;
    }
  });

  kpiRow.innerHTML = `
    <div class="kpi"><div class="num">${tCases}</div><div class="label">Total Cases</div></div>
    <div class="kpi"><div class="num">${tNodes}</div><div class="label">Entities & Events</div></div>
    <div class="kpi"><div class="num">${tEdges}</div><div class="label">Relationships mapped</div></div>
  `;
  document.getElementById('source-legend').innerHTML = `<div class="chip"><span class="dot" style="background:var(--brass)"></span>JSON Ontology Seed</div>`;
}

function renderGraphLegend() {
  const el = document.getElementById('type-legend');
  el.innerHTML = Object.keys(TYPE_COLOR).map(t =>
    `<span><span class="sw" style="background:${TYPE_COLOR[t]}"></span>${TYPE_LABEL[t]||t}</span>`
  ).join('');
}

// Event Listeners
caseFilter.addEventListener('change', (e) => {
  searchInput.value = '';
  selectedNodeId = null;
  updateGraphView(e.target.value === 'ALL' ? 'ALL' : 'CASE', e.target.value);
});

searchInput.addEventListener('input', e => {
  const t = e.target.value.trim().toLowerCase();
  selectedNodeId = null; // Typing overrides click selection
  
  if (!t) {
    updateHighlighting(null);
    return;
  }

  let matches = new Set();
  currentNodes.forEach(n => {
    if(n.name.toLowerCase().includes(t)) {
      matches.add(n.id);
    }
  });
  
  updateHighlighting(matches);
});

// File Upload Handler
fileUpload.addEventListener('change', function(event) {
  const file = event.target.files[0];
  if (!file) return;

  const stamp = document.getElementById('status-stamp');
  stamp.textContent = 'LOADING FILE...';
  stamp.classList.remove('ready');

  const reader = new FileReader();
  reader.onload = function(e) {
    try {
      const json = JSON.parse(e.target.result);
      initData(json);
      // Reset search/details
      searchInput.value = '';
      document.getElementById('detail-panel').innerHTML = '<div class="empty-hint">Click a node in the network to pull its details &mdash; connections, properties and provenance.</div>';
    } catch (err) {
      alert('Error parsing JSON file. Ensure it follows the expected schema.');
      console.error(err);
      stamp.textContent = 'ERROR PARSING JSON';
      stamp.style.color = 'var(--red-alert)';
    }
  };
  reader.readAsText(file);
});

document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
    tab.classList.add('active');
    document.getElementById('view-' + tab.dataset.view).classList.add('active');
  });
});

// Load Default
fetch('pole_plus_model_seed_v1_10_cases.json')
  .then(res => res.json())
  .then(json => initData(json))
  .catch(err => {
    console.error("Failed loading data.", err);
    const stamp = document.getElementById('status-stamp');
    stamp.textContent = 'ERROR LOADING DEFAULT';
    stamp.style.borderColor = 'var(--red-alert)';
    stamp.style.color = 'var(--red-alert)';
  });
